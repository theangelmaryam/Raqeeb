<?php
// Establish a connection to MySQL
$servername = "127.0.0.1";
$username = "root";
$password = "maryaM@1999";

$connection = mysqli_connect($servername, $username, $password, "", 3306);

// Check if the connection was successful
if ($connection) {
    echo "Connected to MySQL<br>";
    
    // Create a database name
    $db_name = "raqeeb";
    
    // Create the database only if it doesn't already exist
    $createDbQuery = "CREATE DATABASE IF NOT EXISTS $db_name";
    
    if (mysqli_query($connection, $createDbQuery)) {
        echo "Database '$db_name' created or already exists.<br>";
        
        // Switch to the Raqeeb database
        $useDbQuery = "USE $db_name";
        if (mysqli_query($connection, $useDbQuery)) {
            
            // Create GUARDIAN table
            $createGuardianTableQuery = "
                CREATE TABLE IF NOT EXISTS GUARDIAN (
                    Id INT AUTO_INCREMENT PRIMARY KEY,
                    Name VARCHAR(255) NOT NULL,
                    Email VARCHAR(255) NOT NULL,
                    Password VARCHAR(255) NOT NULL
                )
            ";
            
            if (mysqli_query($connection, $createGuardianTableQuery)) {
                // Create CHILD table with a foreign key to GUARDIAN
                $createChildTableQuery = "
                    CREATE TABLE IF NOT EXISTS CHILD (
                        Id INT AUTO_INCREMENT PRIMARY KEY,
                        Guardian_Id INT,
                        Name VARCHAR(255) NOT NULL,
                        Birth_date DATE,
                        FOREIGN KEY (Guardian_Id) REFERENCES GUARDIAN(Id)
                    )
                ";
                
                if (mysqli_query($connection, $createChildTableQuery)) {
                    // Create VIDEO table
                    $createVideoTableQuery = "
                        CREATE TABLE IF NOT EXISTS VIDEO (
                            Id INT AUTO_INCREMENT PRIMARY KEY,
                            Uploaded_date DATE,
                            Status VARCHAR(255),
                            Title VARCHAR(255) NOT NULL,
                            Description TEXT,
                            URL VARCHAR(255) NOT NULL
                        )
                    ";
                    
                    if (mysqli_query($connection, $createVideoTableQuery)) {
                        // Create WATCHES table to establish many-to-many relationship between CHILD and VIDEO
                        $createWatchesTableQuery = "
                            CREATE TABLE IF NOT EXISTS WATCHES (
                                Child_Id INT,
                                Video_Id INT,
                                PRIMARY KEY (Child_Id, Video_Id),
                                FOREIGN KEY (Child_Id) REFERENCES CHILD(Id),
                                FOREIGN KEY (Video_Id) REFERENCES VIDEO(Id)
                            )
                        ";
                        
                        if (mysqli_query($connection, $createWatchesTableQuery)) {
                            // Create SAVES table to establish many-to-many relationship between GUARDIAN, CHILD, and VIDEO
                            $createSavesTableQuery = "
                                CREATE TABLE IF NOT EXISTS SAVES (
                                    Guardian_Id INT,
                                    Child_Id INT,
                                    Video_Id INT,
                                    PRIMARY KEY (Guardian_Id, Child_Id, Video_Id),
                                    FOREIGN KEY (Guardian_Id) REFERENCES GUARDIAN(Id),
                                    FOREIGN KEY (Child_Id) REFERENCES CHILD(Id),
                                    FOREIGN KEY (Video_Id) REFERENCES VIDEO(Id)
                                )
                            ";
                            
                            if (mysqli_query($connection, $createSavesTableQuery)) {
                                echo "Tables created successfully or already exist.<br>";
                            } else {
                                echo "Error creating SAVES table: " . mysqli_error($connection) . "<br>";
                            }
                        } else {
                            echo "Error creating WATCHES table: " . mysqli_error($connection) . "<br>";
                        }
                    } else {
                        echo "Error creating VIDEO table: " . mysqli_error($connection) . "<br>";
                    }
                } else {
                    echo "Error creating CHILD table: " . mysqli_error($connection) . "<br>";
                }
            } else {
                echo "Error creating GUARDIAN table: " . mysqli_error($connection) . "<br>";
            }
        } else {
            echo "Error switching to the Raqeeb database: " . mysqli_error($connection) . "<br>";
        }
    } else {
        echo "Error creating database: " . mysqli_error($connection) . "<br>";
    }
    
    // Close the connection
    mysqli_close($connection);
} else {
    echo "Failed to connect to MySQL: " . mysqli_connect_error() . "<br>";
}
?>
